#include <iostream>
#include <string>
#include "Customer.h"
#include "Person.h"

using namespace std;

int main() {
    Customer cust;
    cust.setFields("Boz", "Kubra");
    cust.outputData();
    cust.setBakiye(5600.95);
    cust.bakiyeYaz();

    return 0;

}

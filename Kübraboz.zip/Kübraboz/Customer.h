#include <iostream>
#include <string>
#include "Person.h"

using namespace std;
class Customer :public Person
{

private:
    double bakiye;
public:
    void setBakiye(double);
    void bakiyeYaz();
};

void Customer::setBakiye(double bak) {
    bakiye = bak;
}

void Customer::bakiyeYaz() {
    cout << "Bakiye: " << bakiye<<"TL" <<endl;
}

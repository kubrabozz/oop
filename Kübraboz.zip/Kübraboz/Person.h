#include <iostream>
#include <string>
#ifndef PERSON_H
#define PERSON_H

using namespace std;
class Person {

private:
   
    string ad;
    string soyad;
public:
    void setFields(string, string);
    void outputData();


};

void Person::setFields( string _ad, string _soyad) {
    ad = _ad;
    soyad = _soyad;


}

void Person::outputData()
{
    cout <<  "Isim: " << ad << " " << soyad << endl;
}
#endif
